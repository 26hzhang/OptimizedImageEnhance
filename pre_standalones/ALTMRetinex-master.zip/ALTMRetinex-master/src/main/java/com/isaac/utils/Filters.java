package com.isaac.utils;

import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;

public class Filters {

	static {
		System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
	}

	/**
	 * Guided Image Filter, O(1) time implementation of guided filter
	 *
	 * @param I
	 *            guidance image (should be a gray-scale/single channel image)
	 * @param p
	 *            filtering input image (should be a gray-scale/single channel
	 *            image)
	 * @param r
	 *            local window radius
	 * @param eps
	 *            regularization parameter
	 * @return filtered image
	 */
	public static Mat GuidedImageFilter(Mat I, Mat p, int r, double eps) {
		I.convertTo(I, CvType.CV_64FC1);
		p.convertTo(p, CvType.CV_64FC1);
		//[hei, wid] = size(I);
		int rows = I.rows();
		int cols = I.cols();
		// N = boxfilter(ones(hei, wid), r); % the size of each local patch; N=(2r+1)^2 except for boundary pixels.
		Mat N = new Mat();
		Imgproc.boxFilter(Mat.ones(rows, cols, I.type()), N, -1, new Size(r, r));
		// mean_I = boxfilter(I, r) ./ N;
		Mat mean_I = new Mat();
		Imgproc.boxFilter(I, mean_I, -1, new Size(r, r));
		// mean_p = boxfilter(p, r) ./ N
		Mat mean_p = new Mat();
		Imgproc.boxFilter(p, mean_p, -1, new Size(r, r));
		// mean_Ip = boxfilter(I.*p, r) ./ N;
		Mat mean_Ip = new Mat();
		Imgproc.boxFilter(I.mul(p), mean_Ip, -1, new Size(r, r));
		// cov_Ip = mean_Ip - mean_I .* mean_p; % this is the covariance of (I, p) in each local patch.
		Mat cov_Ip = new Mat();
		Core.subtract(mean_Ip, mean_I.mul(mean_p), cov_Ip);
		// mean_II = boxfilter(I.*I, r) ./ N;
		Mat mean_II = new Mat();
		Imgproc.boxFilter(I.mul(I), mean_II, -1, new Size(r, r));
		// var_I = mean_II - mean_I .* mean_I;
		Mat var_I = new Mat();
		Core.subtract(mean_II, mean_I.mul(mean_I), var_I);
		// a = cov_Ip ./ (var_I + eps); % Eqn. (5) in the paper;
		Mat a = new Mat();
		Core.add(var_I, new Scalar(eps), a);
		Core.divide(cov_Ip, a, a);
		//b = mean_p - a .* mean_I; % Eqn. (6) in the paper;
		Mat b = new Mat();
		Core.subtract(mean_p, a.mul(mean_I), b);
		// mean_a = boxfilter(a, r) ./ N;
		Mat mean_a = new Mat();
		Imgproc.boxFilter(a, mean_a, -1, new Size(r, r));
		Core.divide(mean_a, N, mean_a);
		// mean_b = boxfilter(b, r) ./ N;
		Mat mean_b = new Mat();
		Imgproc.boxFilter(b, mean_b, -1, new Size(r, r));
		Core.divide(mean_b, N, mean_b);
		// q = mean_a .* I + mean_b; % Eqn. (8) in the paper;
		Mat q = new Mat();
		Core.add(mean_a.mul(I), mean_b, q);
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				if (q.get(i, j)[0] <= 0)
					q.put(i, j, 1.0 / 255);
			}
		}
		q.convertTo(q, CvType.CV_32F);
		return q;
	}

}
