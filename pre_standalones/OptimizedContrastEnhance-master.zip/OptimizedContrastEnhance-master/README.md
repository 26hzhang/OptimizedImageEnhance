## Optimized Contrast Enhancement for Dehazing

It is a Java implementation of algorithms proposed in the [paper](http://www.sciencedirect.com/science/article/pii/S1047320313000242): Optimized Contrast Enhancement for Real-time Image and Video Dehazing, published by Jin-Hwan Kim on [JVCIR](https://www.journals.elsevier.com/journal-of-visual-communication-and-image-representation), 2013.

It is a fast and optimized dehazing algorithm for hazy images and videos is proposed in this work. Based on the observation that a hazy image exhibits low contrast in general, they restore the hazy image by enhancing its contrast. However, the overcompensation of the degraded contrast may truncate pixel values and cause information loss. Therefore, they formulate a cost function that consists of the contrast term and the information loss term. By minimizing the cost function, the proposed algorithm enhances the contrast and preserves the information optimally. Moreover, they extend the static image dehazing algorithm to real-time video dehazing. They reduce flickering artifacts in a dehazed video sequence by making trans- mission values temporally coherent.

##### Additional

The image showing method is obtain from the repository: [ImShow-Java-OpenCV](https://github.com/master-atul/ImShow-Java-OpenCV).

The paper and original matlab codes are put in this project too.

**TODO**: impelmentation of video part


### Requirements

* [Java 1.8](http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html).

* [OpenCV](http://opencv.org/). To make the OpenCV can work with JAVA IDE like IntelliJ or Eclipse, you may need to follow the guidance of [OpenCV Java Tutorials](http://opencv-java-tutorials.readthedocs.io/en/latest/01-installing-opencv-for-java.html) to set up OpenCV for Java in your favorite IDE.

### Results

##### Airlight Selection
<img src="README-images/airlight.png" width = "425" height = "425" align=center />

##### Haze Removal Results
<img src="README-images/org-canon.png" width = "425" height = "320" align=center />  <img src="README-images/coarse-canon.png" width = "425" height = "320" align=center />
<img src="README-images/dehaze-canon.png" width = "425" height = "320" align=center />  <img src="README-images/refine-canon.png" width = "425" height = "320" align=center />

<img src="README-images/org-flags.png" width = "425" height = "500" align=center />  <img src="README-images/coarse-flags.png" width = "425" height = "500" align=center />
<img src="README-images/dehaze-flags.png" width = "425" height = "500" align=center />  <img src="README-images/refine-flags.png" width = "425" height = "500" align=center />

<img src="README-images/org-train.png" width = "425" height = "320" align=center />  <img src="README-images/coarse-train.png" width = "425" height = "320" align=center />
<img src="README-images/dehaze-train.png" width = "425" height = "320" align=center />  <img src="README-images/refine-train.png" width = "425" height = "320" align=center />

<img src="README-images/org-ny.png" width = "425" height = "320" align=center />  <img src="README-images/coarse-ny.png" width = "425" height = "320" align=center />
<img src="README-images/dehaze-ny.png" width = "425" height = "320" align=center />  <img src="README-images/refine-ny.png" width = "425" height = "320" align=center />
