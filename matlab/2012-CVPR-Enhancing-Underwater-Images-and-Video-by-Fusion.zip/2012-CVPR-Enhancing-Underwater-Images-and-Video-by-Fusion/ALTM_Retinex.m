%function outval = ALTM_Retinex(img)
img = load_image(12);
img = SimplestColorBalance(img);
img_double = im2double(img);
Ir=double(img_double(:,:,1)); 
Ig=double(img_double(:,:,2)); 
Ib=double(img_double(:,:,3));
% Global Adaptation
Lw = 0.299 * Ir + 0.587 * Ig + 0.114 * Ib;% input world luminance values
Lwmax = max(max(Lw));% the maximum luminance value
[m, n] = size(Lw);
Lwaver = exp(sum(sum(log(0.001 + Lw))) / (m * n));% log-average luminance
Lg = log(Lw / Lwaver + 1) / log(Lwmax / Lwaver + 1);
% Local Adaptation
kenlRatio = 0.01;
krnlsz = floor(max([3, m * kenlRatio, n * kenlRatio]));
Lg1 = imresize(maxfilt2(Lg, [krnlsz, krnlsz]), [m, n]);
Hg = guidedfilter(Lg, Lg1, 10, 0.01);
eta = 36;
alpha = 1 + eta * Lg / max(max(Lg));

Lgaver = exp(sum(sum(log(0.001 + Lg))) / (m * n));
lambda = 10;
beta = lambda * Lgaver;
Lout = alpha .* log(Lg ./ Hg + beta);

Lout = (Lout - min(min(Lout))) / ...
    (max(max(Lout)) - min(min(Lout)));

gain = Lout ./ Lw;
gain(find(Lw == 0)) = 0;
outval = cat(3, gain .* Ir, gain .* Ig, gain .* Ib);
outval = uint8(outval * 255);
figure,imshow(outval)