clc;clear;
img = load_image(57); % 76,69,66
% white balance
img_wb = double(SimplestColorBalance1(img)) / 255;
%figure,imshow(img_wb)
AL = zeros(size(img));
RL = zeros(size(img));
%imshow([double(img) / 255, img_wb])
% image decomposition
for i = 1 : 3
    k = 0.5 * img_wb(:, :, i) / max(max(img_wb(:, :, i)));
    AL(:, :, i) = (1 - k) .* img_wb(:, :, i);
    RL(:, :, i) = k .* img_wb(:, :, i);
end
figure,imshow([RL,AL])
% to gray
img_gray = double(rgb2gray(img))/255;
img = double(img) / 255;
% find the airlight
blksz = 20 * 20;
showFigure = false;
A = AirlightEstimate(AL, blksz, showFigure);

% dark channel
[m, n, ~] = size(img);
dc = zeros(m, n);
for x = 1 : m
    for y = 1 : n
        dc(x, y) = min(img(x, y, :));
    end
end
dc = imresize(minfilt2(dc, [11, 11]), [m, n]);
t = 1 - dc;
r = 150;
eps = 10^-6;
f_img1 = double(rgb2gray(uint8(RL * 255))) / 255;
f_img2 = double(rgb2gray(uint8(AL * 255))) / 255;
t_f = guidedfilter(f_img1, t, r, eps);
t_f2 = guidedfilter(f_img2, t, r, eps);
figure,imshow(t_f)

Lsmooth = bilateralFilter(t_f);
%figure,imshow(Lsmooth)
Ldetail = t_f - Lsmooth;
t_enhanced = Lsmooth + 1.7 * Ldetail;
figure,imshow(t_enhanced)
J(:, :, 1) = (AL(:, :, 1) - A(1)) ./ max(t_enhanced, 0.1) + A(1);
J(:, :, 2) = (AL(:, :, 2) - A(2)) ./ max(t_enhanced, 0.1) + A(2);
J(:, :, 3) = (AL(:, :, 3) - A(3)) ./ max(t_enhanced, 0.1) + A(3);
figure,imshow([img, J+RL])

%figure,imshow([img, J])
