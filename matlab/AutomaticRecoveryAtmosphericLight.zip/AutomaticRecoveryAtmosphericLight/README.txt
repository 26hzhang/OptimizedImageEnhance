Main function is AtmLight.m

The files generateLaplacian.m and makeDarkChannel.m can be downloaded from https://github.com/akutta/Haze-Removal or http://computervisionspring2012.blogspot.co.il/2012/05/final-project-haze-reduction.html