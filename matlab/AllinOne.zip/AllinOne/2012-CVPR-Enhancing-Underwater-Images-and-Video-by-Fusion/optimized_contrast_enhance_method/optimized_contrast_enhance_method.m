function J = optimized_contrast_enhance_method(img)
img = double(img);
[m, n, ~] = size(img);

%**********************find the airlight**********************
%blocksize = 200;
%showFigure = false;
%A = AirlightEstimate(img, blocksize, showFigure);
A = [255, 255, 255];

%******************find the transmission map******************
patchsz = 16; % the size of a patch
% lambda control the relative importance of contrast loss and info loss
lambda = 5;
T = TransEstimate(img, patchsz, A, lambda);

%*****************refine the transmission map*****************
r = 10;
eps = 10^-8;
t = guidedfilter(double(rgb2gray(uint8(img))) / 255, T, r, eps);

%*********************restore the image***********************
J(:,:,1) = (img(:, :, 1) - A(1)) ./ t + A(1);
J(:,:,1) = (J(:, :, 1) - min(min(J(:, :, 1)))) / ...
    (max(max(J(:, :, 1))) - min(min(J(:, :, 1)))) * 255;

J(:,:,2) = (img(:, :, 2) - A(2)) ./ t + A(2);
J(:,:,2) = (J(:, :, 2) - min(min(J(:, :, 2)))) / ...
    (max(max(J(:, :, 2))) - min(min(J(:, :, 2)))) * 255;

J(:,:,3) = (img(:, :, 3) - A(3)) ./ t + A(3);
J(:,:,3) = (J(:, :, 3) - min(min(J(:, :, 3)))) / ...
    (max(max(J(:, :, 3))) - min(min(J(:, :, 3)))) * 255;