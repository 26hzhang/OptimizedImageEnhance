function EdgeDetection(scb, he, icip, cvpr, jvcir, fusion)

figure, edge(rgb2gray(scb),'canny');
figure, edge(rgb2gray(he),'canny');
figure, edge(rgb2gray(icip),'canny');
figure, edge(rgb2gray(cvpr),'canny');
figure, edge(rgb2gray(jvcir),'canny');
figure, edge(rgb2gray(fusion),'canny');