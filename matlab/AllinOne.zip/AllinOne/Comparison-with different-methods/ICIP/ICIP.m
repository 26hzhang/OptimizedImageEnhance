function output = ICIP(img)
output = underwater(img);