function plotRGBColorSpace(scb, he, icip, cvpr, jvcir, fusion)
figure, plot3(scb(:,:,1), scb(:,:,2), scb(:,:,3), '.b')
axis([0 255 0 255 0 255]), grid on
zlabel('Blue'), xlabel('Red'), ylabel('Green')

figure, plot3(he(:,:,1), he(:,:,2), he(:,:,3), '.b')
axis([0 255 0 255 0 255]), grid on
zlabel('Blue'), xlabel('Red'), ylabel('Green')

figure, plot3(icip(:,:,1), icip(:,:,2), icip(:,:,3), '.b')
axis([0 255 0 255 0 255]), grid on
zlabel('Blue'), xlabel('Red'), ylabel('Green')

figure, plot3(cvpr(:,:,1), cvpr(:,:,2), cvpr(:,:,3), '.b')
axis([0 255 0 255 0 255]), grid on
zlabel('Blue'), xlabel('Red'), ylabel('Green')

figure, plot3(jvcir(:,:,1), jvcir(:,:,2), jvcir(:,:,3), '.b')
axis([0 255 0 255 0 255]), grid on
zlabel('Blue'), xlabel('Red'), ylabel('Green')

figure, plot3(fusion(:,:,1), fusion(:,:,2), fusion(:,:,3), '.b')
axis([0 255 0 255 0 255]), grid on
zlabel('Blue'), xlabel('Red'), ylabel('Green')