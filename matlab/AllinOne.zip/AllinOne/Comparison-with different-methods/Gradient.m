function [scbGrad, heGrad, icipGrad, cvprGrad, jvcirGrad, fusionGrad]...
            = Gradient(scb, he, icip, cvpr, jvcir, fusion)

scbGrad = meangrad(double(scb));
heGrad = meangrad(double(he));
icipGrad = meangrad(double(icip));
cvprGrad = meangrad(double(cvpr));
jvcirGrad = meangrad(double(jvcir));
fusionGrad = meangrad(double(fusion));