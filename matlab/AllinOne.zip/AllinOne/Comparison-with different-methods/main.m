addpath(genpath('CVPR'));
addpath(genpath('ICIP'));
addpath(genpath('JVCIR'));
addpath(genpath('Proposed_Method'));

clc, clear
img = loadImage(50);

% retoration results of different methods
ace = imread('50ace.png');
% hsv = rgb2hsv(img);
% hsv(:,:,1) = adapthisteq(hsv(:,:,1), 'NumTiles', [2 2], 'ClipLimit',...
%             0.01, 'NBins', 256, 'Range', 'original', 'Distribution',...
%             'uniform');
% he = hsv2rgb(hsv);
he = CLAHE(img);
icip = ICIP(img);
cvpr = CVPR(img);
jvcir = JVCIR(img);
fusion = proposed(img);
%figure,imshow([scb,he,icip;cvpr,jvcir,fusion])

% Mean Value
[aceMean, heMean, icipMean, cvprMean, jvcirMean, fusionMean]...
            = Mean(ace, he, icip, cvpr, jvcir, fusion);

% Standard Deviation
[aceStd, heStd, icipStd, cvprStd, jvcirStd, fusionStd]...
            = Standard(ace, he, icip, cvpr, jvcir, fusion);

% Average Gradient
[aceGrad, heGrad, icipGrad, cvprGrad, jvcirGrad, fusionGrad]...
            = Gradient(ace, he, icip, cvpr, jvcir, fusion);

% RGB color space
% figure, plot3(img(:,:,1), img(:,:,2), img(:,:,3), '.b')
% axis([0 255 0 255 0 255]), grid on
% zlabel('Blue'), xlabel('Red'), ylabel('Green')
% plotRGBColorSpace(ace, he, icip, cvpr, jvcir, fusion);

% edges detection
% figure, edge(rgb2gray(img),'canny');
% EdgeDetection(ace, he, icip, cvpr, jvcir, fusion);

% UIQM
uiqm = UIQM(img);
aceUiqm = UIQM(ace);
heUiqm = UIQM(he);
icipUiqm = UIQM(icip);
cvprUiqm = UIQM(cvpr);
jvcirUiqm = UIQM(jvcir);
fusionUiqm = UIQM(fusion);


rmpath 'CVPR'
rmpath 'ICIP'
rmpath 'JVCIR'
rmpath 'Proposed_Method'