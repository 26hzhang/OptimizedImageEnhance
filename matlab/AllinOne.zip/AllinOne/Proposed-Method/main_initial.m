clc;clear;
img = loadImage(57); % 76,69,66
img_gray = double(rgb2gray(img))/255;
img = double(img) / 255;
% white balance
%img_wb = SimplestColorBalance1(img);
AL = zeros(size(img));
RL = zeros(size(img));
% image decomposition
for i = 1 : 3
    k = 0.5 * img(:, :, i) / max(max(img(:, :, i)));
    AL(:, :, i) = (1 - k) .* img(:, :, i);
    RL(:, :, i) = k .* img(:, :, i);
end
figure,imshow([RL,AL])
AL = SimplestColorBalance1(AL);
%RL(:,:,1) = adapthisteq(RL(:,:,1));
%RL(:,:,2) = adapthisteq(RL(:,:,2));
%RL(:,:,3) = adapthisteq(RL(:,:,3));
%figure,imshow([RL,AL])
% to gray

% find the airlight
blksz = 20 * 20;
showFigure = false;
A = AirlightEstimate(AL, blksz, showFigure);

% dark channel
[m, n, ~] = size(img);
dc = zeros(m, n);
for x = 1 : m
    for y = 1 : n
        dc(x, y) = min(img(x, y, :));
    end
end
dc = imresize(minfilt2(dc, [11, 11]), [m, n]);
t = 1 - dc;
r = 150;
eps = 10^-6;
f_img = double(rgb2gray(uint8(AL * 255))) / 255;
t_f = guidedfilter(f_img, t, r, eps);
Lsmooth = bilateralFilter(t_f);
Ldetail = t_f - Lsmooth;
t_e = Lsmooth + 1.7 * Ldetail;
%figure,imshow(t_enhanced)

patchsz = 8; 
lambda = 5;
T = TransEstimate(AL, patchsz, A, lambda);
t = guidedfilter(f_img, T, r, eps);
Lsmooth = bilateralFilter(t);
Ldetail = t - Lsmooth;
te = Lsmooth + 1.5 * Ldetail;
%figure,imshow(t)

J(:, :, 1) = (AL(:, :, 1) - A(1)) ./ max(te, 0.1) + A(1);
J(:, :, 2) = (AL(:, :, 2) - A(2)) ./ max(te, 0.1) + A(2);
J(:, :, 3) = (AL(:, :, 3) - A(3)) ./ max(te, 0.1) + A(3);
figure,imshow([RL,AL])
figure,imshow([  J+RL])
%figure,imshow([AL,J])
%figure,imhist(RL(:,:,1))
%figure,imhist(AL(:,:,1))
%figure,imhist([RL(:,:,1)+AL(:,:,1)])