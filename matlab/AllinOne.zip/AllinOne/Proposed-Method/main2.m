% load the parameters
initialParam;

% load the images
img = loadImage(51); % 10, 57, 47, 37, 51, 
%figure,imshow(img)
% white balance process
img_wb = double(SimplestColorBalance(img, 255, 'uint8')) / 255;
% figure,imshow(img_wb)
% image decomposition
%[RL,AL] = imgDecomposition(img_wb);
[RL,AL] = imgDecomposition(double(img) / 255);

% processing the reflex light
RL = normalized(RL, 0.5);
RL = SimplestColorBalance(RL, 0.5, 'double');
figure,imshow([RL,AL])
% processing the alluminance light
A = AirlightEstimate(AL, blksz, showFigure); % find the airlight

% estimate the transmission map
T = TransEstimate(AL, patchsz, A, lambda, r, eps, gamma);

% dehazing process
AL = dehazingProcess(AL, T, A);
%AL = SimplestColorBalance(AL, 0.5, 'double');
figure,imshow([RL,AL])
Input1 = AL + RL;
figure,imshow(Input1)


% fusion process
%[W1, W2] = featureWeight(uint8(RL * 255), uint8(AL * 255));
%Fusion = pyramidFuse(W1, W2, uint8(RL * 255), uint8(AL * 255));

%plotColorSpace(double(img) / 255, img_wb, double(Fusion) / 255)
%plotHistogram(double(img) / 255, img_wb, double(Fusion) / 255)