clc;clear;

%kk = 0.5;
% parameters for finding the airlight
blksz = 20 * 20;
showFigure = false;

% parameters for estimating the transmission map
patchsz = 8; 
lambda = 10;
gamma = 1.7;
r = 150;
eps = 10^-6;