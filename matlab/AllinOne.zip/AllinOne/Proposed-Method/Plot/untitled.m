I = loadImage(57);
hsv = rgb2hsv(I);
[rows, columns, numberOfColorBands] = size(I);
h = hsv(:,:,1);
scaledHue = 255*h;
figure,imagesc(scaledHue), axis image, truesize; colorbar
figure,
numberOfBins = 256;
[pixelCount, grayLevels] = hist(h(:), numberOfBins);
cmap = jet(numberOfBins);
r = pixelCount / max(pixelCount(:));
drawWheel(r,cmap);