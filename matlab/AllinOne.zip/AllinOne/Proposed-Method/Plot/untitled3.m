I = loadImage(47);
uicm = UICM(I)
