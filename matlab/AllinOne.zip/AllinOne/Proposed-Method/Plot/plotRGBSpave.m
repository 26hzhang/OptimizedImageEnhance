I = loadImage(47);
% [m,n,~] = size(I);
% Ir = reshape(I(:,:,1), 1, m*n);
% Ig = reshape(I(:,:,2), 1, m*n);
% Ib = reshape(I(:,:,3), 1, m*n);
% plot3(Ir,Ig,Ib,'.g');
% axis([0 255 0 255 0 255])
% zlabel('Blue'), xlabel('Red'), ylabel('Green')
% grid on

X = edge(rgb2gray(I),'canny');