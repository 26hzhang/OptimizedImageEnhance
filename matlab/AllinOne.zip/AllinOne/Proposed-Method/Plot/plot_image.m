img = loadImage(57);

img_red = img;
img_red(:,:,1) = 0;
img_red(:,:,2) = 0;
figure,
imshow(img_red)

figure,
imhist(img_red(:,:,3));
hold on
plot([128,128],[0,8000],'black')
grid on
hold off