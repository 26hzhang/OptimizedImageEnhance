% load the parameters
initialParam;

% load the images
img = loadImage(57); % 10,57,47,45,37,51,50,39,36,32,20,4,101,102
%[meanRG, deltaRG, meanYB, deltaYB, uicm] = UICM(img)
%uism1 = UIConM(img)
%figure,edge(rgb2gray(img), 'canny')
%[meanRG, deltaRG, meanYB, deltaYB, uicm] = UICM(img)

%figure,imshow(img)
% white balance process
%img_wb = double(SimplestColorBalance(img, 255, 'uint8')) / 255;
%figure,imshow(img_wb)
% image decomposition
%[RL,AL] = imgDecomposition(img_wb);
[RL,AL] = imgDecomposition(double(img) / 255);
%figure,
%imhist(uint8(AL(:,:,1) * 255));
%hold on
%imhist(uint8(AL(:,:,2) * 255));
%imhist(uint8(AL(:,:,3) * 255));
%hold off
%AL1 = AL;
%figure,imshow(RL)
%figure,imshow(AL)
%figure,imshow([RL,AL])
% processing the reflex light
%RL1 = RL;
%RL = CLAHE(RL);
%RL = normalized(RL, 0.5);
%figure,imshow(RL)
RL = SimplestColorBalance(RL, 0.5, 'double');
%figure,imshow(RL)
%figure,
%imhist(uint8(RL(:,:,1) / max(max(RL(:,:,1))) * 0.5 * 255));
%hold on
%imhist(uint8(RL(:,:,2) / max(max(RL(:,:,2))) * 0.5 * 255));
%imhist(uint8(RL(:,:,3) / max(max(RL(:,:,3))) * 0.5 * 255));
%figure,imshow([RL1,RL])

% processing the alluminance light
A = AirlightEstimate(AL, blksz, showFigure); % find the airlight
%A = [max(max(AL(:,:,1))), max(max(AL(:,:,2))), max(max(AL(:,:,3)))];

% estimate the transmission map
T = TransEstimate(AL, patchsz, A, lambda, r, eps, gamma);

% dehazing process
AL = dehazingProcess(AL, T, A);
%figure,imshow([AL])

%hold off
%AL = SimplestColorBalance(AL, 0.5, 'double');
%figure,imshow([AL1,AL])
%figure,imshow([RL,AL])
%figure,imshow(AL+RL)
%figure,imshow([double(img) / 255, img_wb, AL+RL])

% fusion process
[W1, W2] = featureWeight(uint8(RL * 255), uint8(AL * 255));
%Fusion_tmp(:,:,1) = W1.*RL(:,:,1)+W2.*AL(:,:,1);
%Fusion_tmp(:,:,2) = W1.*RL(:,:,2)+W2.*AL(:,:,2);
%Fusion_tmp(:,:,3) = W1.*RL(:,:,3)+W2.*AL(:,:,3);
%figure, imshow(Fusion_tmp)
Fusion = pyramidFuse(W1, W2, uint8(RL * 255), uint8(AL * 255));
% X = edge(rgb2gray(Fusion), 'canny');
% F = Fusion;
% for i = 1 : size(X,1)
%     for j = 1 : size(X,2)
%         if X(i,j) == 1
%             F(i,j,1) = 255;
%             F(i,j,2) = 0;
%             F(i,j,3) = 0;
%         end
%     end
% end
% figure,imshow([F])
[meanRG, deltaRG, meanYB, deltaYB, uicm] = UICM(Fusion)
uism = UISM(Fusion)
uiconm = UIConM(Fusion)
uiqm = UIQM(Fusion)
%figure,imshow([Fusion])
% figure,
% subplot(121)
% imhist(img(:,:,1));
% hold on
% imhist(img(:,:,2));
% imhist(img(:,:,3));
% plot([128,128],[0,8000],'black')
% grid on
% hold off
% subplot(122)
% imhist(Fusion(:,:,1));
% hold on
% imhist(Fusion(:,:,2));
% imhist(Fusion(:,:,3));
% plot([128,128],[0,8000],'black')
% grid on
% hold off
%figure,imshow([double(img)/255, img_wb; AL+RL, double(Fusion) / 255])
%plotColorSpace(double(img) / 255, img_wb, double(Fusion) / 255)
%plotHistogram(double(img) / 255, img_wb, double(Fusion) / 255)