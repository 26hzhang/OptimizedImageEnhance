% load image
num = 47; % 57,51,50,47,36,37,38
img = double(load_image(num));
% estiamte A
blocksize = 200;
showFigure = false;
A = AirlightEstimate(img, blocksize, showFigure);
% Simplest Color Balance
SCB_img = SimplestColorBalance(img);

t_r = (img(:,:,1) - A(1)) ./ (SCB_img(:,:,1) - A(1));
t_g = (img(:,:,2) - A(2)) ./ (SCB_img(:,:,2) - A(2));
t_b = (img(:,:,3) - A(3)) ./ (SCB_img(:,:,3) - A(3));
figure,imshow([t_r,t_g,t_b])
%figure,imagesc([t_r,t_g,t_b]), axis image, truesize; colorbar